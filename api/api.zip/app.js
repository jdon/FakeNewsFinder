var port = process.env.PORT || 3000;
var express = require('express');
var app = express();
var fs = require('fs');

app.get('/', function(req,res) {
	res.send("DICKS OUT");
});

app.listen(port);